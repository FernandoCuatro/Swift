//
//  main.swift
//  Ejercicio4
//
//  Created by Fernando Cuatro on 2/17/24.
//  Copyright © 2024 Fernando Cuatro. All rights reserved.
//

import Foundation

let spiderman = Superheroe("Spiderman");
print(spiderman.verSuperheroe())
