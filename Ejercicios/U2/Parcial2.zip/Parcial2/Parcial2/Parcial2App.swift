//
//  Parcial2App.swift
//  Parcial2
//
//  Created by Fernando Cuatro on 3/16/24.
//

import SwiftUI

@main
struct Parcial2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
