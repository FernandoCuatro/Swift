//
//  Constans.swift
//  Parcial2
//
//  Created by Fernando Cuatro on 3/16/24.
//

import Foundation
import SwiftUI

let naranja = Color(#colorLiteral( red: 0.978567183, green: 0.6576827168, blue: 0.2109591961, alpha: 1))
let morado = Color(#colorLiteral(red: 0.55, green: 0.09, blue: 0.26, alpha: 1))
let oscuro = Color(#colorLiteral(red: 0.473857868, green: 0.08282086867, blue: 0.2380903248, alpha: 1))


