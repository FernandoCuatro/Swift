//
//  Constantes.swift
//  frutero
//
//  Created by Fernando Cuatro on 3/9/24.
//

import SwiftUI

let colorNaranja = Color(#colorLiteral(red: 0.9607843161, green: 0.7058823705, blue: 0.200000003, alpha: 1))
// array de toda la vida
let titles = ["Pupusas","Tamales","Yuca","Tamales de pollo","Sopa de pata","Mariscada","Jocotes"]
