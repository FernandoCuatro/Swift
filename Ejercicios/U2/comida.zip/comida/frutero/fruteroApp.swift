//
//  fruteroApp.swift
//  frutero
//
//  Created by Fernando Cuatro on 3/9/24.
//

import SwiftUI

@main
struct fruteroApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
