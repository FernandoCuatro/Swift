//
//  SimbolosApp.swift
//  Simbolos
//
//  Created by Fernando Cuatro on 3/2/24.
//

import SwiftUI

@main
struct SimbolosApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
